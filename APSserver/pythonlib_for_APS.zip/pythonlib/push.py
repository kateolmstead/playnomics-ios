from apns import APNs, Payload, PayloadAlert

apns = APNs(use_sandbox=True, cert_file='PushProofCert.pem', key_file='PushProofKey.pem')

# Send a notification
# This is the token we receive from app delegate, without spaces
token_hex = '55d55b6071b53a3712142d7abf6cab49beba06fb6a3dcc41f14c4ee1036b3790'
# remove any spaces, should we have some
token_hex = token_hex.replace(" ","")
# remove any open/close carrots , which are typical of apple device tokens
token_hex = token_hex.replace("<","")
token_hex = token_hex.replace(">","")

#payload = Payload(alert="Hello World!", sound="default", badge=1)

alert = PayloadAlert("Hello world!", action_loc_key="example_lock_key")
payload = Payload(alert=alert, sound="default", custom={'push_id':123,"push_message":"push messages are soooo cool."})

apns.gateway_server.send_notification(token_hex, payload)